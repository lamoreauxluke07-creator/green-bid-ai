# 📋 Implementation Steps

Quick guide to customize your platform:

## Phase 1: Branding (15 min)
1. **Company Name:** Update `/components/Header.tsx` line 31
2. **Hero Title:** Update `/components/Hero.tsx` lines 16-18  
3. **Test:** Save and refresh browser

## Phase 2: Content (30 min)
1. **Features:** Modify `/data/features.tsx`
2. **Pricing:** Update `/data/pricing.tsx`
3. **Colors:** Edit `/styles/globals.css` CSS variables

## Phase 3: Industry Focus (20 min)
Copy examples from `/examples/` folder:
- HVAC: Use `PersonalizedHero_HVAC.tsx`
- Solar: Use `PersonalizedHero_Solar.tsx`  
- Roofing: Use `PersonalizedFeatures_Roofing.tsx`

## Quick Edits

**Header (Company Name):**
```tsx
// Line 31 in /components/Header.tsx
<span className="font-semibold text-xl">Your Company Name</span>
```

**Hero Headline:**
```tsx  
// Lines 16-18 in /components/Hero.tsx
<h1 className="text-4xl lg:text-6xl tracking-tight">
  Your Industry-Specific Headline
</h1>
```

**Colors:**
```css
/* In /styles/globals.css */
:root {
  --primary: #your-brand-color;
}
```

## File Structure
- `/components/Header.tsx` - Company name & navigation
- `/components/Hero.tsx` - Main headline section  
- `/data/features.tsx` - Features list
- `/data/pricing.tsx` - Pricing plans
- `/styles/globals.css` - Colors & branding