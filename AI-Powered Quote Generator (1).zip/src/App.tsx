import { useState, useEffect } from 'react';
import { Header } from './components/Header';
import { Hero } from './components/Hero';
import { Features } from './components/Features';
import { HowItWorks } from './components/HowItWorks';
import { Pricing } from './components/Pricing';
import { QuoteGenerator } from './components/QuoteGenerator';
import { Dashboard } from './components/Dashboard';
import { Footer } from './components/Footer';
import { AuthModal } from './components/AuthModal';
import { supabase } from './utils/supabase/client';
import type { User } from './utils/supabase/client';

type ViewType = 'home' | 'quote' | 'dashboard';

export default function App() {
  const [currentView, setCurrentView] = useState<ViewType>('home');
  const [user, setUser] = useState<User | null>(null);
  const [showAuthModal, setShowAuthModal] = useState(false);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Check for existing session
    supabase.auth.getSession().then(({ data: { session } }) => {
      setUser(session?.user as User || null);
      setLoading(false);
    });

    // Listen for auth changes
    const { data: { subscription } } = supabase.auth.onAuthStateChange((_event, session) => {
      setUser(session?.user as User || null);
      setLoading(false);
    });

    return () => subscription.unsubscribe();
  }, []);

  const handleGetStarted = () => {
    if (user) {
      setCurrentView('quote');
    } else {
      setShowAuthModal(true);
    }
  };

  const handleAuthSuccess = () => {
    setShowAuthModal(false);
    setCurrentView('quote');
  };

  const renderContent = () => {
    if (loading) {
      return (
        <div className="min-h-screen flex items-center justify-center">
          <div className="text-center">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto mb-4"></div>
            <p>Loading...</p>
          </div>
        </div>
      );
    }

    switch (currentView) {
      case 'quote':
        return <QuoteGenerator user={user} onBack={() => setCurrentView('home')} onAuthRequired={() => setShowAuthModal(true)} />;
      case 'dashboard':
        return user ? <Dashboard user={user} onBack={() => setCurrentView('home')} /> : null;
      default:
        return (
          <>
            <Hero onGetStarted={handleGetStarted} />
            <Features />
            <HowItWorks />
            <Pricing onGetStarted={handleGetStarted} />
          </>
        );
    }
  };

  // Redirect to home if trying to access dashboard without auth
  if (currentView === 'dashboard' && !user) {
    setCurrentView('home');
  }

  return (
    <div className="min-h-screen bg-background">
      <Header 
        currentView={currentView}
        onViewChange={setCurrentView}
        user={user}
        onAuthRequired={() => setShowAuthModal(true)}
      />
      <main>
        {renderContent()}
      </main>
      {currentView === 'home' && <Footer />}
      
      {showAuthModal && (
        <AuthModal 
          onClose={() => setShowAuthModal(false)}
          onSuccess={handleAuthSuccess}
        />
      )}
    </div>
  );
}