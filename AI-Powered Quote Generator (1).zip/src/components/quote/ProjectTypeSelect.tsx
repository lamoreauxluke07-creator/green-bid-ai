import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../ui/select';
import { Label } from '../ui/label';

interface ProjectTypeSelectProps {
  value: string;
  onChange: (value: string) => void;
}

export const PROJECT_TYPES = [
  { value: 'landscaping', label: 'Landscaping' },
  { value: 'hardscaping', label: 'Hardscaping' },
  { value: 'driveway', label: 'Driveway' },
  { value: 'patio', label: 'Patio & Deck' },
  { value: 'fencing', label: 'Fencing' },
  { value: 'retaining-wall', label: 'Retaining Wall' }
];

export function ProjectTypeSelect({ value, onChange }: ProjectTypeSelectProps) {
  return (
    <div className="space-y-2">
      <Label htmlFor="project-type">Project Type</Label>
      <Select value={value} onValueChange={onChange}>
        <SelectTrigger>
          <SelectValue placeholder="Select project type" />
        </SelectTrigger>
        <SelectContent>
          {PROJECT_TYPES.map((type) => (
            <SelectItem key={type.value} value={type.value}>
              {type.label}
            </SelectItem>
          ))}
        </SelectContent>
      </Select>
    </div>
  );
}