import { Card, CardContent } from './ui/card';
import { features, trustMetrics } from '../data/features';

export function Features() {
  return (
    <section className="py-20 bg-muted/30">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-3xl lg:text-4xl mb-4">
            Everything You Need to Quote Faster
          </h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            Our AI-powered platform combines computer vision, machine learning, and industry expertise 
            to deliver the most accurate quotes in the market.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {features.map((feature, index) => (
            <Card key={index} className="h-full">
              <CardContent className="p-6">
                <div className="mb-4">
                  <feature.icon className="h-12 w-12 text-primary" />
                </div>
                <h3 className="text-xl mb-3">{feature.title}</h3>
                <p className="text-muted-foreground">{feature.description}</p>
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="mt-16 bg-primary text-primary-foreground rounded-2xl p-8 lg:p-12">
          <div className="text-center space-y-4">
            <h3 className="text-2xl lg:text-3xl">
              {trustMetrics.title}
            </h3>
            <p className="text-lg opacity-90 max-w-2xl mx-auto">
              {trustMetrics.description}
            </p>
            <div className="flex justify-center items-center space-x-12 pt-8">
              {trustMetrics.stats.map((stat, index) => (
                <div key={index} className="text-center">
                  <div className="text-3xl">{stat.value}</div>
                  <div className="text-sm opacity-80">{stat.label}</div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}