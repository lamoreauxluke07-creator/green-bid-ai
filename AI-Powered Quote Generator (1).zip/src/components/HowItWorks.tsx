import { Upload, Scan, FileText, Send } from 'lucide-react';
import { ImageWithFallback } from './figma/ImageWithFallback';

const steps = [
  {
    icon: Upload,
    title: 'Upload Photos',
    description: 'Take or upload photos of the property from multiple angles for best results.'
  },
  {
    icon: Scan,
    title: 'AI Analysis',
    description: 'Our AI analyzes the images to identify surfaces, materials, and project requirements.'
  },
  {
    icon: FileText,
    title: 'Generate Quote',
    description: 'Detailed quote with materials, labor costs, timeline, and project breakdown.'
  },
  {
    icon: Send,
    title: 'Send to Client',
    description: 'Professional PDF quote ready to send with customizable branding and terms.'
  }
];

export function HowItWorks() {
  return (
    <section className="py-20">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-3xl lg:text-4xl mb-4">
            From Photo to Quote in 4 Simple Steps
          </h2>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Our streamlined process makes quote generation effortless and accurate.
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-16 items-center">
          <div className="space-y-8">
            {steps.map((step, index) => (
              <div key={index} className="flex items-start space-x-4">
                <div className="flex-shrink-0 w-12 h-12 bg-primary text-primary-foreground rounded-full flex items-center justify-center">
                  <step.icon className="h-6 w-6" />
                </div>
                <div>
                  <h3 className="text-lg mb-2">
                    {index + 1}. {step.title}
                  </h3>
                  <p className="text-muted-foreground">{step.description}</p>
                </div>
              </div>
            ))}
            
            <div className="pt-8">
              <div className="bg-muted/50 rounded-lg p-6">
                <h4 className="mb-3">Supported Project Types</h4>
                <div className="grid grid-cols-2 gap-2 text-sm">
                  <div>✓ Landscaping</div>
                  <div>✓ Hardscaping</div>
                  <div>✓ Driveways</div>
                  <div>✓ Patios & Decks</div>
                  <div>✓ Fencing</div>
                  <div>✓ Retaining Walls</div>
                  <div>✓ Outdoor Lighting</div>
                  <div>✓ Irrigation Systems</div>
                </div>
              </div>
            </div>
          </div>

          <div className="relative">
            <div className="aspect-[4/3] rounded-2xl overflow-hidden bg-muted/50 shadow-2xl">
              <ImageWithFallback
                src="https://images.unsplash.com/photo-1635111031688-9b13c0125d12?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwcm9wZXJ0eSUyMGhvdXNlJTIwYWVyaWFsfGVufDF8fHx8MTc1NjQ3NDc5NHww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
                alt="Aerial view of property"
                className="w-full h-full object-cover"
              />
            </div>
            
            {/* Process Animation Overlay */}
            <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent rounded-2xl flex items-end">
              <div className="p-6 text-white">
                <div className="text-sm opacity-80 mb-1">Processing...</div>
                <div className="text-lg">Analyzing property dimensions</div>
                <div className="w-32 h-2 bg-white/20 rounded-full mt-2">
                  <div className="w-3/4 h-full bg-white rounded-full"></div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}