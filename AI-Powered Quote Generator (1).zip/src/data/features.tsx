import { Camera, Brain, Clock, Shield, TrendingUp, Users } from 'lucide-react';

export const features = [
  {
    icon: Camera,
    title: 'Smart Photo Analysis',
    description: 'AI analyzes property photos to identify surfaces, materials, and project scope automatically.'
  },
  {
    icon: Brain,
    title: 'AI-Powered Calculations',
    description: 'Advanced algorithms calculate accurate material costs, labor hours, and project timelines.'
  },
  {
    icon: Clock,
    title: 'Instant Results',
    description: 'Generate detailed quotes in seconds, not hours. Speed up your sales process dramatically.'
  },
  {
    icon: Shield,
    title: 'Accurate Estimates',
    description: '95% accuracy rate with built-in safety margins and local pricing data integration.'
  },
  {
    icon: TrendingUp,
    title: 'Profit Optimization',
    description: 'Smart pricing suggestions help maximize your profit margins while staying competitive.'
  },
  {
    icon: Users,
    title: 'Team Collaboration',
    description: 'Share quotes with team members, track revisions, and manage client communications.'
  }
];

export const trustMetrics = {
  title: 'Trusted by Leading Contractors',
  description: 'Join thousands of landscaping and construction professionals who have transformed their quoting process with Green Bid AI.',
  stats: [
    { value: '500+', label: 'Active Companies' },
    { value: '$50M+', label: 'Quotes Generated' },
    { value: '4.9/5', label: 'Customer Rating' }
  ]
};