export const plans = [
  {
    name: 'Starter',
    price: 49,
    period: 'month',
    description: 'Perfect for small contractors getting started',
    features: [
      '50 quotes per month',
      'Basic photo analysis',
      'Standard templates',
      'Email support',
      'PDF export'
    ],
    popular: false
  },
  {
    name: 'Professional',
    price: 99,
    period: 'month',
    description: 'Most popular for growing businesses',
    features: [
      '200 quotes per month',
      'Advanced AI analysis',
      'Custom branding',
      'Priority support',
      'Quote tracking',
      'Client portal',
      'Mobile app access'
    ],
    popular: true
  },
  {
    name: 'Enterprise',
    price: 199,
    period: 'month',
    description: 'For large operations and agencies',
    features: [
      'Unlimited quotes',
      'Premium AI features',
      'White-label solution',
      'Dedicated support',
      'API access',
      'Team management',
      'Advanced analytics',
      'Custom integrations'
    ],
    popular: false
  }
];

export const guarantees = [
  'No hidden fees',
  '24/7 support',
  'Money-back guarantee'
];