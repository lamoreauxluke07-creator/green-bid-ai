import { createClient } from '@supabase/supabase-js'
import { projectId, publicAnonKey } from './info'

const supabaseUrl = `https://${projectId}.supabase.co`

// Debug connection info
console.log('Supabase URL:', supabaseUrl)
console.log('Public Key:', publicAnonKey?.substring(0, 20) + '...')

export const supabase = createClient(supabaseUrl, publicAnonKey, {
  auth: {
    persistSession: true,
    autoRefreshToken: true,
    detectSessionInUrl: true,
  }
})

// Test the connection
supabase.auth.getSession().then(({ data, error }) => {
  if (error) {
    console.error('Supabase connection error:', error)
  } else {
    console.log('Supabase connected successfully, session:', data.session?.user?.email || 'none')
  }
})

export type User = {
  id: string
  email: string
  user_metadata: {
    name: string
    company: string
  }
}

export type Quote = {
  id: string
  userId: string
  clientInfo: {
    name: string
    email: string
    phone: string
    address: string
  }
  projectType: string
  photos: Array<{
    path: string
    url: string
    size: number
    type: string
  }>
  analysis: {
    area: number
    surfaces: string[]
    materials: string[]
    complexity: string
  }
  breakdown: Array<{
    category: string
    amount: number
    items: string[]
  }>
  totalCost: number
  timeline: string
  status: 'draft' | 'sent' | 'accepted' | 'declined'
  createdAt: string
  updatedAt?: string
  validUntil: string
}

export type UserProfile = {
  id: string
  email: string
  name: string
  company: string
  subscription: 'starter' | 'professional' | 'enterprise'
  quotesUsed: number
  createdAt: string
}