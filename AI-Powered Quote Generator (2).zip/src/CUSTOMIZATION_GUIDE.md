# 🚀 Customization Guide

Transform the QuoteVision platform for your business in 3 simple steps:

## ⚡ Quick Start (30 minutes)

### 1. Update Company Info
- Change "QuoteVision AI" in `/components/Header.tsx` line 31
- Update hero headline in `/components/Hero.tsx` lines 16-18
- Modify features in `/data/features.tsx`
- Adjust pricing in `/data/pricing.tsx`

### 2. Industry Examples
**HVAC:** "AI-Powered HVAC Quotes from Property Photos"
**Solar:** "Solar Installation Quotes from Satellite Imagery" 
**Roofing:** "Accurate Roofing Estimates from Aerial Analysis"
**Landscaping:** "Professional Landscape Design with Instant Quotes"

### 3. Key Files to Customize
- `/components/Header.tsx` - Company name & navigation
- `/components/Hero.tsx` - Main headline & description  
- `/data/features.tsx` - Feature list & benefits
- `/data/pricing.tsx` - Pricing plans & features
- `/styles/globals.css` - Colors & branding

## 🎨 Customization Tips

**Branding:** Update CSS variables in globals.css for colors
**Content:** Replace stock images with your project photos
**Features:** Modify feature icons and descriptions for your industry
**Pricing:** Adjust plans and pricing for your market

## 📁 File Structure
```
/components/Header.tsx      # Company name & nav
/components/Hero.tsx        # Main headline section
/data/features.tsx          # Features list
/data/pricing.tsx           # Pricing plans  
/styles/globals.css         # Colors & styling
```

See `/examples/` folder for industry-specific component examples.