import { Home, Ruler, CloudRain, Shield, Calculator, Users } from 'lucide-react';
import { Card, CardContent } from '../components/ui/card';

// Example: Features customized for a Roofing company
const roofingFeatures = [
  {
    icon: Home,
    title: 'Aerial Roof Analysis',
    description: 'Satellite and drone imagery analysis to measure roof dimensions, pitch, and complexity automatically.'
  },
  {
    icon: Ruler,
    title: 'Precise Measurements',
    description: 'AI calculates exact square footage, ridge length, and material requirements with 99% accuracy.'
  },
  {
    icon: CloudRain,
    title: 'Weather Resistance Assessment',
    description: 'Evaluates local climate conditions to recommend appropriate materials and installation methods.'
  },
  {
    icon: Shield,
    title: 'Insurance Integration',
    description: 'Generate detailed reports compatible with insurance claims and adjuster requirements.'
  },
  {
    icon: Calculator,
    title: 'Material Optimization',
    description: 'Smart calculations minimize waste while ensuring proper coverage and code compliance.'
  },
  {
    icon: Users,
    title: 'Homeowner Portal',
    description: 'Professional presentation tools to share quotes, timelines, and project progress with clients.'
  }
];

export function PersonalizedFeatures_Roofing() {
  return (
    <section className="py-20 bg-muted/30">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-3xl lg:text-4xl mb-4">
            Everything You Need for Roofing Estimates
          </h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            Our AI-powered platform combines satellite imagery, weather data, and roofing expertise 
            to deliver the most accurate roof replacement and repair quotes in the industry.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {roofingFeatures.map((feature, index) => (
            <Card key={index} className="h-full">
              <CardContent className="p-6">
                <div className="mb-4">
                  <feature.icon className="h-12 w-12 text-primary" />
                </div>
                <h3 className="text-xl mb-3">{feature.title}</h3>
                <p className="text-muted-foreground">{feature.description}</p>
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="mt-16 bg-primary text-primary-foreground rounded-2xl p-8 lg:p-12">
          <div className="text-center space-y-4">
            <h3 className="text-2xl lg:text-3xl">
              Trusted by Leading Roofing Contractors
            </h3>
            <p className="text-lg opacity-90 max-w-2xl mx-auto">
              Join hundreds of roofing professionals who have streamlined their estimation process 
              and increased their close rate with our AI-powered platform.
            </p>
            <div className="flex justify-center items-center space-x-12 pt-8">
              <div className="text-center">
                <div className="text-3xl">250+</div>
                <div className="text-sm opacity-80">Roofing Companies</div>
              </div>
              <div className="text-center">
                <div className="text-3xl">15,000+</div>
                <div className="text-sm opacity-80">Roofs Analyzed</div>
              </div>
              <div className="text-center">
                <div className="text-3xl">35%</div>
                <div className="text-sm opacity-80">Higher Close Rate</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}