# 🌿 Green Bid AI

AI-powered quote generation platform designed specifically for landscaping and construction companies. Transform property photos into professional, detailed quotes in minutes.

## 🚀 Features

- **📸 Photo Analysis**: Upload property photos and get instant AI analysis
- **🧠 Smart Quotes**: Generate detailed quotes with materials, labor, and timelines
- **📊 Dashboard**: Track quotes, client interactions, and business analytics
- **💼 Professional PDF**: Export branded quotes ready for client presentation
- **📱 Responsive Design**: Works seamlessly on desktop and mobile
- **🔐 Secure Authentication**: User accounts with Supabase integration
- **☁️ Cloud Storage**: Secure photo storage and quote management

## 🛠️ Tech Stack

- **Frontend**: React + TypeScript + Tailwind CSS v4
- **Backend**: Supabase (Database, Auth, Storage, Edge Functions)
- **AI Processing**: Custom quote generation algorithms
- **Hosting**: Vercel-ready deployment
- **Components**: Shadcn/ui component library

## 🏗️ Supported Project Types

- ✅ Landscaping & Garden Design
- ✅ Hardscaping (Patios, Walkways)
- ✅ Driveways & Parking Areas
- ✅ Fencing & Privacy Solutions
- ✅ Retaining Walls
- ✅ Outdoor Lighting Systems
- ✅ Irrigation & Sprinkler Systems
- ✅ Deck & Outdoor Structure Construction

## 🚀 Quick Start

### Prerequisites

- Node.js 18+ and npm
- Supabase account ([supabase.com](https://supabase.com))

### Installation

1. **Clone the repository**
   ```bash
   git clone https://github.com/yourusername/green-bid-ai.git
   cd green-bid-ai
   ```

2. **Install dependencies**
   ```bash
   npm install
   ```

3. **Set up environment variables**
   ```bash
   cp .env.example .env.local
   # Edit .env.local with your Supabase keys
   ```

4. **Start development server**
   ```bash
   npm run dev
   ```

5. **Open your browser**
   Navigate to `http://localhost:5173`

## ⚙️ Environment Setup

### Supabase Configuration

1. Create a new Supabase project
2. Get your project URL and anon key from Settings → API
3. Update `.env.local` with your keys:

```env
VITE_SUPABASE_URL=https://your-project.supabase.co
VITE_SUPABASE_ANON_KEY=your_anon_key
SUPABASE_SERVICE_ROLE_KEY=your_service_role_key
SUPABASE_DB_URL=your_database_url
```

### Deployment to Production

The easiest way to deploy Green Bid AI is using [Vercel](https://vercel.com):

1. Push your code to GitHub
2. Connect your GitHub repo to Vercel
3. Add environment variables in Vercel dashboard
4. Deploy automatically on every push

**Estimated monthly costs:**
- Development: Free (Supabase + Vercel free tiers)
- Production: ~$45/month (Supabase Pro + Vercel Pro)

## 📁 Project Structure

```
├── components/           # React components
│   ├── ui/              # Shadcn/ui components
│   ├── quote/           # Quote generation components
│   └── figma/           # Figma integration components
├── data/                # Static data and configurations
├── styles/              # Global CSS and Tailwind config
├── supabase/            # Supabase functions and schema
├── utils/               # Utility functions and API clients
├── examples/            # Usage examples and templates
└── docs/                # Documentation files
```

## 🎨 Customization

Green Bid AI is built to be easily customizable for different service businesses:

- **Branding**: Update colors, logos, and company info
- **Project Types**: Modify supported service categories
- **Pricing Models**: Adjust pricing tiers and features
- **Quote Templates**: Customize quote layouts and content

See `CUSTOMIZATION_GUIDE.md` for detailed instructions.

## 📊 Business Model

- **Subscription-based SaaS**: Monthly/annual pricing tiers
- **Usage-based billing**: Pay per quote generated
- **Enterprise solutions**: Custom integrations and white-label options

## 🔒 Security & Privacy

- All sensitive data encrypted at rest
- GDPR compliant data handling
- Secure photo storage with automatic deletion options
- Role-based access control for team accounts

## 🤝 Contributing

This is a proprietary business application. For partnership opportunities or custom integrations, contact:

**Green Bid AI**  
📧 lukelam07@gmail.com  
📱 (607) 361-2035  
📍 Horseheads, NY

## 📄 License

Proprietary software. All rights reserved.

## 🛣️ Roadmap

- [ ] Mobile app development (iOS/Android)
- [ ] Advanced AI features (drone photo analysis)
- [ ] Team collaboration tools
- [ ] API for third-party integrations
- [ ] Multi-language support
- [ ] Advanced analytics and reporting

---

**Built with ❤️ for the landscaping and construction industry**

*Helping contractors win more business through professional, AI-powered quotes*