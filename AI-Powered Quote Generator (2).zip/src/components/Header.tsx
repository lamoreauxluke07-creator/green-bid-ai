import { Button } from './ui/button';
import { Camera, Menu, X, LogOut } from 'lucide-react';
import { useState } from 'react';
import { api } from '../utils/api';
import type { User } from '../utils/supabase/client';

interface HeaderProps {
  currentView: 'home' | 'quote' | 'dashboard';
  onViewChange: (view: 'home' | 'quote' | 'dashboard') => void;
  user: User | null;
  onAuthRequired: () => void;
}

export function Header({ currentView, onViewChange, user, onAuthRequired }: HeaderProps) {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  const handleSignOut = async () => {
    try {
      await api.signOut();
      onViewChange('home');
    } catch (error) {
      console.error('Sign out error:', error);
    }
  };

  return (
    <header className="sticky top-0 z-50 bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60 border-b">
      <div className="container mx-auto px-4 h-16 flex items-center justify-between">
        <div className="flex items-center space-x-2">
          <Camera className="h-8 w-8 text-primary" />
          <span className="font-semibold text-xl">Green Bid AI</span>
        </div>

        {/* Desktop Navigation */}
        <nav className="hidden md:flex items-center space-x-6">
          <button
            onClick={() => onViewChange('home')}
            className={`transition-colors ${
              currentView === 'home' ? 'text-primary' : 'text-muted-foreground hover:text-foreground'
            }`}
          >
            Home
          </button>
          <button
            onClick={() => onViewChange('quote')}
            className={`transition-colors ${
              currentView === 'quote' ? 'text-primary' : 'text-muted-foreground hover:text-foreground'
            }`}
          >
            Get Quote
          </button>
          {user && (
            <button
              onClick={() => onViewChange('dashboard')}
              className={`transition-colors ${
                currentView === 'dashboard' ? 'text-primary' : 'text-muted-foreground hover:text-foreground'
              }`}
            >
              Dashboard
            </button>
          )}
        </nav>

        {/* Desktop Actions */}
        <div className="hidden md:flex items-center space-x-4">
          {!user ? (
            <>
              <Button variant="ghost" onClick={onAuthRequired}>
                Sign In
              </Button>
              <Button onClick={onAuthRequired}>
                Get Started
              </Button>
            </>
          ) : (
            <>
              <span className="text-sm text-muted-foreground">
                {user.user_metadata?.name || user.email}
              </span>
              <Button variant="ghost" size="sm" onClick={handleSignOut}>
                <LogOut className="h-4 w-4 mr-2" />
                Sign Out
              </Button>
            </>
          )}
        </div>

        {/* Mobile Menu Button */}
        <Button
          variant="ghost"
          size="sm"
          className="md:hidden"
          onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
        >
          {isMobileMenuOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
        </Button>
      </div>

      {/* Mobile Menu */}
      {isMobileMenuOpen && (
        <div className="md:hidden bg-background border-b">
          <div className="container mx-auto px-4 py-4 space-y-4">
            <button
              onClick={() => {
                onViewChange('home');
                setIsMobileMenuOpen(false);
              }}
              className={`block w-full text-left transition-colors ${
                currentView === 'home' ? 'text-primary' : 'text-muted-foreground'
              }`}
            >
              Home
            </button>
            <button
              onClick={() => {
                onViewChange('quote');
                setIsMobileMenuOpen(false);
              }}
              className={`block w-full text-left transition-colors ${
                currentView === 'quote' ? 'text-primary' : 'text-muted-foreground'
              }`}
            >
              Get Quote
            </button>
            {user && (
              <button
                onClick={() => {
                  onViewChange('dashboard');
                  setIsMobileMenuOpen(false);
                }}
                className={`block w-full text-left transition-colors ${
                  currentView === 'dashboard' ? 'text-primary' : 'text-muted-foreground'
                }`}
              >
                Dashboard
              </button>
            )}
            <div className="pt-4 space-y-2">
              {!user ? (
                <>
                  <Button 
                    variant="ghost" 
                    className="w-full justify-start"
                    onClick={() => {
                      onAuthRequired();
                      setIsMobileMenuOpen(false);
                    }}
                  >
                    Sign In
                  </Button>
                  <Button 
                    className="w-full"
                    onClick={() => {
                      onAuthRequired();
                      setIsMobileMenuOpen(false);
                    }}
                  >
                    Get Started
                  </Button>
                </>
              ) : (
                <>
                  <div className="text-sm text-muted-foreground px-3 py-2">
                    {user.user_metadata?.name || user.email}
                  </div>
                  <Button 
                    variant="outline" 
                    className="w-full justify-start"
                    onClick={() => {
                      handleSignOut();
                      setIsMobileMenuOpen(false);
                    }}
                  >
                    <LogOut className="h-4 w-4 mr-2" />
                    Sign Out
                  </Button>
                </>
              )}
            </div>
          </div>
        </div>
      )}
    </header>
  );
}