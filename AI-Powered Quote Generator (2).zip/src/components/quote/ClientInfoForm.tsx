import { Input } from '../ui/input';
import { Label } from '../ui/label';

export interface ClientInfo {
  name: string;
  email: string;
  phone: string;
  address: string;
}

interface ClientInfoFormProps {
  clientInfo: ClientInfo;
  onChange: (info: ClientInfo) => void;
}

export function ClientInfoForm({ clientInfo, onChange }: ClientInfoFormProps) {
  const updateField = (field: keyof ClientInfo, value: string) => {
    onChange({ ...clientInfo, [field]: value });
  };

  return (
    <>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="space-y-2">
          <Label htmlFor="client-name">Client Name</Label>
          <Input
            id="client-name"
            placeholder="Enter client name"
            value={clientInfo.name}
            onChange={(e) => updateField('name', e.target.value)}
            required
          />
        </div>
        <div className="space-y-2">
          <Label htmlFor="client-email">Email</Label>
          <Input
            id="client-email"
            type="email"
            placeholder="client@email.com"
            value={clientInfo.email}
            onChange={(e) => updateField('email', e.target.value)}
            required
          />
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="space-y-2">
          <Label htmlFor="client-phone">Phone</Label>
          <Input
            id="client-phone"
            placeholder="(555) 123-4567"
            value={clientInfo.phone}
            onChange={(e) => updateField('phone', e.target.value)}
          />
        </div>
        <div className="space-y-2">
          <Label htmlFor="client-address">Property Address</Label>
          <Input
            id="client-address"
            placeholder="123 Main St, City, State"
            value={clientInfo.address}
            onChange={(e) => updateField('address', e.target.value)}
            required
          />
        </div>
      </div>
    </>
  );
}