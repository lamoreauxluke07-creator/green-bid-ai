import { Button } from '../ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { FileText, Download, Share, ArrowLeft } from 'lucide-react';
import type { Quote } from '../../utils/supabase/client';

interface QuoteResultsProps {
  quote: Quote;
  onBack: () => void;
}

export function QuoteResults({ quote, onBack }: QuoteResultsProps) {
  return (
    <div className="min-h-screen bg-muted/30 py-20">
      <div className="container mx-auto px-4 max-w-4xl">
        <div className="mb-8">
          <Button variant="ghost" onClick={onBack} className="mb-4">
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back to Home
          </Button>
          <h1 className="text-3xl mb-2">Your Quote is Ready!</h1>
          <p className="text-muted-foreground">
            Based on your photos, here's your detailed project estimate
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-8">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <FileText className="h-5 w-5" />
                <span>Quote Summary</span>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div>
                <div className="text-3xl text-primary mb-2">
                  ${quote.totalCost.toLocaleString()}
                </div>
                <div className="text-muted-foreground">{quote.projectType}</div>
              </div>

              <div className="space-y-4">
                <div className="flex justify-between">
                  <span>Project Area:</span>
                  <span>{quote.analysis.area} sq ft</span>
                </div>
                <div className="flex justify-between">
                  <span>Timeline:</span>
                  <span>{quote.timeline}</span>
                </div>
                <div className="flex justify-between">
                  <span>Client:</span>
                  <span>{quote.clientInfo.name}</span>
                </div>
              </div>

              <div className="space-y-3">
                <h4>Detected Features:</h4>
                <ul className="space-y-1">
                  {quote.analysis.surfaces.map((surface, index) => (
                    <li key={index} className="text-sm text-muted-foreground">
                      • {surface}
                    </li>
                  ))}
                </ul>
              </div>

              <div className="flex space-x-3">
                <Button className="flex-1">
                  <Download className="h-4 w-4 mr-2" />
                  Download PDF
                </Button>
                <Button variant="outline" className="flex-1">
                  <Share className="h-4 w-4 mr-2" />
                  Share Quote
                </Button>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Cost Breakdown</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {quote.breakdown.map((item, index) => (
                  <div key={index}>
                    <div className="flex justify-between items-center mb-2">
                      <span>{item.category}</span>
                      <span>${item.amount.toLocaleString()}</span>
                    </div>
                    <div className="text-sm text-muted-foreground mb-2">
                      {item.items.join(', ')}
                    </div>
                    <div className="w-full bg-muted rounded-full h-2">
                      <div 
                        className="bg-primary h-2 rounded-full"
                        style={{
                          width: `${(item.amount / quote.totalCost) * 100}%`
                        }}
                      ></div>
                    </div>
                  </div>
                ))}
              </div>

              <div className="mt-6 pt-4 border-t">
                <div className="flex justify-between text-lg">
                  <span>Total Project Cost:</span>
                  <span className="text-primary">
                    ${quote.totalCost.toLocaleString()}
                  </span>
                </div>
                <p className="text-sm text-muted-foreground mt-2">
                  *Quote valid for 30 days. Final pricing may vary based on site conditions.
                </p>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}