import { useState, useEffect } from 'react';
import { Button } from './ui/button';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Badge } from './ui/badge';
import { 
  ArrowLeft, 
  FileText, 
  Eye, 
  Download, 
  Share2,
  TrendingUp,
  Calendar,
  DollarSign,
  Users,
  Loader2
} from 'lucide-react';
import { api } from '../utils/api';
import type { User, Quote, UserProfile } from '../utils/supabase/client';

interface DashboardProps {
  user: User;
  onBack: () => void;
}

export function Dashboard({ user, onBack }: DashboardProps) {
  const [quotes, setQuotes] = useState<Quote[]>([]);
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    const loadDashboardData = async () => {
      try {
        setLoading(true);
        const [quotesData, profileData] = await Promise.all([
          api.getQuotes(),
          api.getProfile()
        ]);
        setQuotes(quotesData);
        setProfile(profileData);
      } catch (error: any) {
        setError(error.message || 'Failed to load dashboard data');
      } finally {
        setLoading(false);
      }
    };

    loadDashboardData();
  }, []);

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'accepted': return 'bg-green-100 text-green-800';
      case 'sent': return 'bg-blue-100 text-blue-800';
      case 'draft': return 'bg-yellow-100 text-yellow-800';
      case 'declined': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const stats = {
    totalQuotes: quotes.length,
    acceptedQuotes: quotes.filter(q => q.status === 'accepted').length,
    totalRevenue: quotes.filter(q => q.status === 'accepted').reduce((sum, q) => sum + q.totalCost, 0),
    avgQuoteValue: quotes.length > 0 ? Math.round(quotes.reduce((sum, q) => sum + q.totalCost, 0) / quotes.length) : 0
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-muted/30 py-20">
        <div className="container mx-auto px-4 max-w-7xl">
          <div className="flex items-center justify-center h-64">
            <div className="text-center">
              <Loader2 className="h-8 w-8 animate-spin mx-auto mb-4" />
              <p>Loading dashboard...</p>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-muted/30 py-20">
      <div className="container mx-auto px-4 max-w-7xl">
        <div className="mb-8">
          <Button variant="ghost" onClick={onBack} className="mb-4">
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back to Home
          </Button>
          <h1 className="text-3xl mb-2">Dashboard</h1>
          <p className="text-muted-foreground">
            Welcome back, {profile?.name || user.user_metadata?.name}! Manage your quotes and track your business performance.
          </p>
        </div>

        {error && (
          <div className="mb-6 p-4 bg-destructive/10 text-destructive rounded-lg">
            {error}
          </div>
        )}

        {/* Stats Overview */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Total Quotes</p>
                  <p className="text-3xl">{stats.totalQuotes}</p>
                </div>
                <FileText className="h-8 w-8 text-primary" />
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Accepted</p>
                  <p className="text-3xl">{stats.acceptedQuotes}</p>
                </div>
                <TrendingUp className="h-8 w-8 text-green-500" />
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Total Revenue</p>
                  <p className="text-3xl">${(stats.totalRevenue / 1000).toFixed(0)}k</p>
                </div>
                <DollarSign className="h-8 w-8 text-green-500" />
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Avg Quote</p>
                  <p className="text-3xl">${(stats.avgQuoteValue / 1000).toFixed(1)}k</p>
                </div>
                <Users className="h-8 w-8 text-blue-500" />
              </div>
            </CardContent>
          </Card>
        </div>

        <Tabs defaultValue="quotes" className="space-y-6">
          <TabsList>
            <TabsTrigger value="quotes">Recent Quotes</TabsTrigger>
            <TabsTrigger value="analytics">Analytics</TabsTrigger>
            <TabsTrigger value="settings">Settings</TabsTrigger>
          </TabsList>

          <TabsContent value="quotes">
            <Card>
              <CardHeader>
                <CardTitle>Recent Quotes</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {quotes.length === 0 ? (
                    <div className="text-center py-12">
                      <FileText className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                      <h3 className="text-lg mb-2">No quotes yet</h3>
                      <p className="text-muted-foreground">Generate your first quote to get started!</p>
                    </div>
                  ) : (
                    quotes.map((quote) => (
                      <div key={quote.id} className="flex items-center justify-between p-4 border rounded-lg hover:bg-muted/50 transition-colors">
                        <div className="flex-1">
                          <div className="flex items-center space-x-3 mb-2">
                            <h3 className="font-medium">{quote.clientInfo.name}</h3>
                            <Badge className={getStatusColor(quote.status)}>
                              {quote.status}
                            </Badge>
                          </div>
                          <p className="text-sm text-muted-foreground mb-1">{quote.projectType}</p>
                          <div className="flex items-center space-x-4 text-sm text-muted-foreground">
                            <span className="flex items-center">
                              <Calendar className="h-4 w-4 mr-1" />
                              {new Date(quote.createdAt).toLocaleDateString()}
                            </span>
                            <span>${quote.totalCost.toLocaleString()}</span>
                            <span>{quote.timeline}</span>
                          </div>
                        </div>
                        <div className="flex items-center space-x-2">
                          <Button variant="ghost" size="sm">
                            <Eye className="h-4 w-4" />
                          </Button>
                          <Button variant="ghost" size="sm">
                            <Download className="h-4 w-4" />
                          </Button>
                          <Button variant="ghost" size="sm">
                            <Share2 className="h-4 w-4" />
                          </Button>
                        </div>
                      </div>
                    ))
                  )}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="analytics">
            <div className="grid lg:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle>Quote Performance</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex justify-between items-center">
                      <span>Acceptance Rate</span>
                      <span className="text-green-600">
                        {stats.totalQuotes > 0 ? Math.round((stats.acceptedQuotes / stats.totalQuotes) * 100) : 0}%
                      </span>
                    </div>
                    <div className="w-full bg-muted rounded-full h-2">
                      <div 
                        className="bg-green-500 h-2 rounded-full"
                        style={{
                          width: `${stats.totalQuotes > 0 ? (stats.acceptedQuotes / stats.totalQuotes) * 100 : 0}%`
                        }}
                      ></div>
                    </div>
                    
                    <div className="flex justify-between items-center">
                      <span>Total Value</span>
                      <span className="text-blue-600">${stats.totalRevenue.toLocaleString()}</span>
                    </div>
                    
                    <div className="flex justify-between items-center">
                      <span>Average Quote Value</span>
                      <span>${stats.avgQuoteValue.toLocaleString()}</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Monthly Trends</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex justify-between">
                      <span>This Month</span>
                      <span className="text-primary">8 quotes</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Last Month</span>
                      <span>12 quotes</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Growth</span>
                      <span className="text-red-600">-33%</span>
                    </div>
                    <div className="pt-4 text-sm text-muted-foreground">
                      Revenue is up 15% despite fewer quotes, indicating higher-value projects.
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="settings">
            <div className="grid lg:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle>Account Settings</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <label className="block text-sm mb-2">Company Name</label>
                    <input 
                      type="text" 
                      className="w-full p-3 border rounded-lg bg-background"
                      defaultValue={profile?.company || user.user_metadata?.company || ''}
                    />
                  </div>
                  <div>
                    <label className="block text-sm mb-2">Contact Email</label>
                    <input 
                      type="email" 
                      className="w-full p-3 border rounded-lg bg-background"
                      defaultValue={profile?.email || user.email || ''}
                    />
                  </div>
                  <Button>Update Profile</Button>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Subscription</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex justify-between items-center">
                    <span>Current Plan</span>
                    <Badge>{profile?.subscription || 'Starter'}</Badge>
                  </div>
                  <div className="flex justify-between items-center">
                    <span>Quotes Used</span>
                    <span>{profile?.quotesUsed || 0} / {profile?.subscription === 'enterprise' ? '∞' : profile?.subscription === 'professional' ? '200' : '50'}</span>
                  </div>
                  <div className="w-full bg-muted rounded-full h-2">
                    <div 
                      className="bg-primary h-2 rounded-full"
                      style={{
                        width: `${profile?.subscription === 'enterprise' ? 25 : (profile?.quotesUsed || 0) / (profile?.subscription === 'professional' ? 200 : 50) * 100}%`
                      }}
                    ></div>
                  </div>
                  <div className="flex justify-between items-center">
                    <span>Next Billing</span>
                    <span>Feb 15, 2025</span>
                  </div>
                  <Button variant="outline" className="w-full">
                    Manage Subscription
                  </Button>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}