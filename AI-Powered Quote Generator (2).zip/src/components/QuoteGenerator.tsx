import { useState, useCallback } from 'react';
import { Button } from './ui/button';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { ArrowLeft } from 'lucide-react';
import { api } from '../utils/api';
import type { User, Quote } from '../utils/supabase/client';
import { ProjectTypeSelect } from './quote/ProjectTypeSelect';
import { ClientInfoForm, type ClientInfo } from './quote/ClientInfoForm';
import { ProcessingStep } from './quote/ProcessingStep';
import { PhotoUpload } from './quote/PhotoUpload';
import { QuoteResults } from './quote/QuoteResults';

interface QuoteGeneratorProps {
  user: User | null;
  onBack: () => void;
  onAuthRequired: () => void;
}

type Step = 'upload' | 'client-info' | 'processing' | 'results';

export function QuoteGenerator({ user, onBack, onAuthRequired }: QuoteGeneratorProps) {
  const [currentStep, setCurrentStep] = useState<Step>('upload');
  const [uploadedImages, setUploadedImages] = useState<File[]>([]);
  const [uploadedPhotos, setUploadedPhotos] = useState<any[]>([]);
  const [progress, setProgress] = useState(0);
  const [error, setError] = useState('');
  const [generatedQuote, setGeneratedQuote] = useState<Quote | null>(null);
  const [clientInfo, setClientInfo] = useState<ClientInfo>({
    name: '',
    email: '',
    phone: '',
    address: ''
  });
  const [projectType, setProjectType] = useState('landscaping');

  const handleImageUpload = useCallback((files: FileList | null) => {
    if (files) {
      const newImages = Array.from(files).filter(file => file.type.startsWith('image/'));
      setUploadedImages(prev => [...prev, ...newImages]);
    }
  }, []);



  const uploadPhotos = async () => {
    if (!user) {
      onAuthRequired();
      return;
    }

    if (uploadedImages.length === 0) {
      setError('Please upload at least one photo');
      return;
    }

    try {
      setError('');
      const photos = await api.uploadPhotos(uploadedImages);
      setUploadedPhotos(photos);
      setCurrentStep('client-info');
    } catch (error: any) {
      setError(error.message || 'Failed to upload photos');
    }
  };

  const generateQuote = async () => {
    if (!user) {
      onAuthRequired();
      return;
    }

    setCurrentStep('processing');
    setProgress(10);
    setError('');

    try {
      // Simulate AI processing stages
      const stages = [
        'Uploading photos...',
        'Analyzing images...',
        'Detecting surfaces...',
        'Calculating measurements...',
        'Estimating materials...',
        'Generating quote...'
      ];

      for (let i = 0; i < stages.length; i++) {
        await new Promise(resolve => setTimeout(resolve, 800));
        setProgress((i + 1) * (100 / stages.length));
      }

      const quote = await api.generateQuote(uploadedPhotos, projectType, clientInfo);
      setGeneratedQuote(quote);
      setCurrentStep('results');
    } catch (error: any) {
      setError(error.message || 'Failed to generate quote');
      setCurrentStep('client-info');
    }
  };

  const removeImage = (index: number) => {
    setUploadedImages(prev => prev.filter((_, i) => i !== index));
  };

  if (currentStep === 'processing') {
    return <ProcessingStep progress={progress} />;
  }

  if (currentStep === 'client-info') {
    return (
      <div className="min-h-screen bg-muted/30 py-20">
        <div className="container mx-auto px-4 max-w-2xl">
          <div className="mb-8">
            <Button variant="ghost" onClick={() => setCurrentStep('upload')} className="mb-4">
              <ArrowLeft className="h-4 w-4 mr-2" />
              Back to Photos
            </Button>
            <h1 className="text-3xl mb-2">Client Information</h1>
            <p className="text-muted-foreground">
              Enter client details to generate your quote
            </p>
          </div>

          <Card>
            <CardHeader>
              <CardTitle>Project Details</CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <ProjectTypeSelect value={projectType} onChange={setProjectType} />
              <ClientInfoForm clientInfo={clientInfo} onChange={setClientInfo} />

              {error && (
                <div className="text-sm text-destructive bg-destructive/10 p-3 rounded-lg">
                  {error}
                </div>
              )}

              <Button 
                className="w-full" 
                size="lg"
                onClick={generateQuote}
                disabled={!clientInfo.name || !clientInfo.email || !clientInfo.address}
              >
                Generate Quote
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  if (currentStep === 'results' && generatedQuote) {
    return <QuoteResults quote={generatedQuote} onBack={onBack} />;
  }

  return (
    <div className="min-h-screen bg-muted/30 py-20">
      <div className="container mx-auto px-4 max-w-4xl">
        <div className="mb-8">
          <Button variant="ghost" onClick={onBack} className="mb-4">
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back to Home
          </Button>
          <h1 className="text-3xl mb-2">Generate Your Quote</h1>
          <p className="text-muted-foreground">
            Upload photos of your property to get an instant AI-powered quote
          </p>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>Upload Property Photos</CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            <PhotoUpload
              uploadedImages={uploadedImages}
              onImageUpload={handleImageUpload}
              onRemoveImage={removeImage}
            />

            {error && (
              <div className="text-sm text-destructive bg-destructive/10 p-3 rounded-lg">
                {error}
              </div>
            )}

            <Button 
              className="w-full" 
              size="lg"
              disabled={uploadedImages.length === 0}
              onClick={uploadPhotos}
            >
              Continue with {uploadedImages.length} photo{uploadedImages.length !== 1 ? 's' : ''}
            </Button>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}