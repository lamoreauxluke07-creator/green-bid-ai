import { Hono } from 'npm:hono'
import { cors } from 'npm:hono/cors'
import { logger } from 'npm:hono/logger'
import { createClient } from 'npm:@supabase/supabase-js@2'
import * as kv from './kv_store.tsx'

const app = new Hono()

app.use('*', cors({
  origin: '*',
  allowHeaders: ['*'],
  allowMethods: ['*'],
}))

app.use('*', logger(console.log))

// Initialize Supabase clients
const supabaseAdmin = createClient(
  Deno.env.get('SUPABASE_URL')!,
  Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!,
)

const supabaseClient = createClient(
  Deno.env.get('SUPABASE_URL')!,
  Deno.env.get('SUPABASE_ANON_KEY')!,
)

// Initialize storage bucket
const bucketName = 'make-3608529e-property-photos'

async function initializeBucket() {
  const { data: buckets } = await supabaseAdmin.storage.listBuckets()
  const bucketExists = buckets?.some(bucket => bucket.name === bucketName)
  
  if (!bucketExists) {
    console.log('Creating storage bucket...')
    const { error } = await supabaseAdmin.storage.createBucket(bucketName, {
      public: false,
      allowedMimeTypes: ['image/jpeg', 'image/png', 'image/webp']
    })
    if (error) {
      console.error('Error creating bucket:', error)
    } else {
      console.log('Storage bucket created successfully')
    }
  }
}

// Initialize bucket on startup
initializeBucket()

// Helper function to get authenticated user
async function getAuthenticatedUser(request: Request) {
  const accessToken = request.headers.get('Authorization')?.split(' ')[1]
  if (!accessToken) {
    return null
  }
  
  const { data: { user }, error } = await supabaseAdmin.auth.getUser(accessToken)
  if (error || !user) {
    return null
  }
  
  return user
}

// User registration endpoint - now supports both admin creation and profile initialization
app.post('/make-server-3608529e/auth/signup', async (c) => {
  try {
    const { email, password, name, company, userId } = await c.req.json()
    
    let user
    
    if (userId) {
      // User was already created via frontend, just initialize profile
      user = { id: userId }
    } else {
      // Legacy flow - create user via admin API
      const { data, error } = await supabaseAdmin.auth.admin.createUser({
        email,
        password,
        user_metadata: { name, company },
        // Automatically confirm the user's email since an email server hasn't been configured.
        email_confirm: true
      })
      
      if (error) {
        console.error('Admin signup error:', error)
        return c.json({ error: error.message }, 400)
      }
      
      user = data.user
    }
    
    // Initialize user profile in KV store
    await kv.set(`user:${user.id}`, {
      id: user.id,
      email,
      name,
      company,
      subscription: 'starter',
      quotesUsed: 0,
      createdAt: new Date().toISOString()
    })
    
    return c.json({ user })
  } catch (error) {
    console.error('Signup error:', error)
    return c.json({ error: 'Internal server error during signup' }, 500)
  }
})

// Upload property photos endpoint
app.post('/make-server-3608529e/photos/upload', async (c) => {
  try {
    const user = await getAuthenticatedUser(c.req)
    if (!user) {
      return c.json({ error: 'Unauthorized' }, 401)
    }
    
    const formData = await c.req.formData()
    const files = formData.getAll('photos') as File[]
    
    if (!files.length) {
      return c.json({ error: 'No photos provided' }, 400)
    }
    
    const uploadedFiles = []
    
    for (const file of files) {
      const fileExt = file.name.split('.').pop()
      const fileName = `${user.id}/${Date.now()}-${Math.random().toString(36).substring(7)}.${fileExt}`
      
      const { data, error } = await supabaseAdmin.storage
        .from(bucketName)
        .upload(fileName, file, {
          contentType: file.type
        })
      
      if (error) {
        console.error('File upload error:', error)
        continue
      }
      
      // Generate signed URL for the uploaded file
      const { data: signedUrl, error: urlError } = await supabaseAdmin.storage
        .from(bucketName)
        .createSignedUrl(fileName, 60 * 60 * 24) // 24 hours
      
      if (!urlError && signedUrl) {
        uploadedFiles.push({
          path: fileName,
          url: signedUrl.signedUrl,
          size: file.size,
          type: file.type
        })
      }
    }
    
    return c.json({ files: uploadedFiles })
  } catch (error) {
    console.error('Photo upload error:', error)
    return c.json({ error: 'Error uploading photos' }, 500)
  }
})

// Generate quote endpoint
app.post('/make-server-3608529e/quotes/generate', async (c) => {
  try {
    const user = await getAuthenticatedUser(c.req)
    if (!user) {
      return c.json({ error: 'Unauthorized' }, 401)
    }
    
    const { photos, projectType, clientInfo } = await c.req.json()
    
    // Check user's quota
    const userProfile = await kv.get(`user:${user.id}`)
    if (!userProfile) {
      return c.json({ error: 'User profile not found' }, 404)
    }
    
    const quoteLimits = {
      starter: 50,
      professional: 200,
      enterprise: -1 // unlimited
    }
    
    const limit = quoteLimits[userProfile.subscription] || 50
    if (limit !== -1 && userProfile.quotesUsed >= limit) {
      return c.json({ error: 'Quote limit exceeded for current subscription' }, 403)
    }
    
    // Simulate AI processing (in real implementation, this would call actual AI services)
    const mockAnalysis = {
      area: Math.floor(Math.random() * 500) + 200,
      surfaces: ['patio', 'lawn', 'walkway'],
      materials: ['pavers', 'soil', 'plants'],
      complexity: Math.random() > 0.5 ? 'high' : 'medium'
    }
    
    // Calculate quote based on analysis
    const baseCost = mockAnalysis.area * (projectType === 'landscaping' ? 15 : 25)
    const materialsCost = Math.floor(baseCost * 0.6)
    const laborCost = Math.floor(baseCost * 0.3)
    const equipmentCost = Math.floor(baseCost * 0.08)
    const permitsCost = Math.floor(baseCost * 0.02)
    
    const totalCost = materialsCost + laborCost + equipmentCost + permitsCost
    
    const quote = {
      id: `Q-${Date.now()}`,
      userId: user.id,
      clientInfo,
      projectType,
      photos,
      analysis: mockAnalysis,
      breakdown: [
        { category: 'Materials', amount: materialsCost, items: ['Pavers', 'Stone', 'Plants', 'Soil'] },
        { category: 'Labor', amount: laborCost, items: ['Installation', 'Preparation', 'Cleanup'] },
        { category: 'Equipment', amount: equipmentCost, items: ['Excavator rental', 'Tools'] },
        { category: 'Permits', amount: permitsCost, items: ['City permits', 'HOA approval'] }
      ],
      totalCost,
      timeline: mockAnalysis.complexity === 'high' ? '7-10 business days' : '5-7 business days',
      status: 'draft',
      createdAt: new Date().toISOString(),
      validUntil: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString() // 30 days
    }
    
    // Save quote
    await kv.set(`quote:${quote.id}`, quote)
    
    // Update user's quote count
    await kv.set(`user:${user.id}`, {
      ...userProfile,
      quotesUsed: userProfile.quotesUsed + 1
    })
    
    // Add to user's quotes list
    const userQuotes = await kv.get(`user_quotes:${user.id}`) || []
    userQuotes.unshift(quote.id)
    await kv.set(`user_quotes:${user.id}`, userQuotes.slice(0, 100)) // Keep last 100 quotes
    
    return c.json({ quote })
  } catch (error) {
    console.error('Quote generation error:', error)
    return c.json({ error: 'Error generating quote' }, 500)
  }
})

// Get user quotes endpoint
app.get('/make-server-3608529e/quotes', async (c) => {
  try {
    const user = await getAuthenticatedUser(c.req)
    if (!user) {
      return c.json({ error: 'Unauthorized' }, 401)
    }
    
    const quoteIds = await kv.get(`user_quotes:${user.id}`) || []
    const quotes = await kv.mget(quoteIds.map(id => `quote:${id}`))
    
    return c.json({ quotes: quotes.filter(Boolean) })
  } catch (error) {
    console.error('Get quotes error:', error)
    return c.json({ error: 'Error fetching quotes' }, 500)
  }
})

// Get specific quote endpoint
app.get('/make-server-3608529e/quotes/:id', async (c) => {
  try {
    const user = await getAuthenticatedUser(c.req)
    if (!user) {
      return c.json({ error: 'Unauthorized' }, 401)
    }
    
    const quoteId = c.req.param('id')
    const quote = await kv.get(`quote:${quoteId}`)
    
    if (!quote || quote.userId !== user.id) {
      return c.json({ error: 'Quote not found' }, 404)
    }
    
    return c.json({ quote })
  } catch (error) {
    console.error('Get quote error:', error)
    return c.json({ error: 'Error fetching quote' }, 500)
  }
})

// Update quote status endpoint
app.patch('/make-server-3608529e/quotes/:id', async (c) => {
  try {
    const user = await getAuthenticatedUser(c.req)
    if (!user) {
      return c.json({ error: 'Unauthorized' }, 401)
    }
    
    const quoteId = c.req.param('id')
    const { status } = await c.req.json()
    
    const quote = await kv.get(`quote:${quoteId}`)
    if (!quote || quote.userId !== user.id) {
      return c.json({ error: 'Quote not found' }, 404)
    }
    
    const updatedQuote = {
      ...quote,
      status,
      updatedAt: new Date().toISOString()
    }
    
    await kv.set(`quote:${quoteId}`, updatedQuote)
    
    return c.json({ quote: updatedQuote })
  } catch (error) {
    console.error('Update quote error:', error)
    return c.json({ error: 'Error updating quote' }, 500)
  }
})

// Get user profile endpoint
app.get('/make-server-3608529e/profile', async (c) => {
  try {
    const user = await getAuthenticatedUser(c.req)
    if (!user) {
      return c.json({ error: 'Unauthorized' }, 401)
    }
    
    const profile = await kv.get(`user:${user.id}`)
    if (!profile) {
      return c.json({ error: 'Profile not found' }, 404)
    }
    
    return c.json({ profile })
  } catch (error) {
    console.error('Get profile error:', error)
    return c.json({ error: 'Error fetching profile' }, 500)
  }
})

// Health check endpoint
app.get('/make-server-3608529e/health', (c) => {
  return c.json({ status: 'ok', timestamp: new Date().toISOString() })
})

Deno.serve(app.fetch)