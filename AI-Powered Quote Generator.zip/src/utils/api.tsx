import { projectId, publicAnonKey } from './supabase/info'
import { supabase, Quote, UserProfile } from './supabase/client'

const baseUrl = `https://${projectId}.supabase.co/functions/v1/make-server-3608529e`

class ApiError extends Error {
  constructor(message: string, public status: number) {
    super(message)
    this.name = 'ApiError'
  }
}

async function apiRequest(endpoint: string, options: RequestInit = {}) {
  const session = await supabase.auth.getSession()
  const accessToken = session.data.session?.access_token || publicAnonKey

  const response = await fetch(`${baseUrl}${endpoint}`, {
    ...options,
    headers: {
      'Authorization': `Bearer ${accessToken}`,
      'Content-Type': 'application/json',
      ...options.headers,
    },
  })

  if (!response.ok) {
    const errorData = await response.json().catch(() => ({ error: 'Unknown error' }))
    throw new ApiError(errorData.error || `HTTP ${response.status}`, response.status)
  }

  return response.json()
}

export const api = {
  // Authentication
  async signUp(email: string, password: string, name: string, company: string) {
    try {
      console.log('Starting signup process for:', email)
      
      // Validate inputs
      if (!email || !password || !name || !company) {
        throw new ApiError('All fields are required', 400)
      }

      // First, try to sign up using Supabase client directly
      const { data: authData, error: authError } = await supabase.auth.signUp({
        email,
        password,
        options: {
          data: {
            name,
            company,
          }
        }
      })

      if (authError) {
        console.error('Supabase signup error:', authError)
        throw new ApiError(authError.message, 400)
      }

      console.log('Supabase signup successful:', authData.user?.email)

      // If successful, also create the user profile in our backend
      if (authData.user) {
        try {
          const response = await fetch(`${baseUrl}/auth/signup`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ 
              email, 
              password, 
              name, 
              company,
              userId: authData.user.id 
            }),
          })

          if (!response.ok) {
            const errorData = await response.json().catch(() => ({}))
            console.warn('Backend profile creation failed:', errorData)
          } else {
            console.log('Backend profile created successfully')
          }
        } catch (backendError) {
          console.warn('Backend profile creation failed:', backendError)
          // Don't throw here since auth succeeded
        }
      }

      return authData
    } catch (error) {
      console.error('Signup API error:', error)
      throw error
    }
  },

  async signIn(email: string, password: string) {
    try {
      console.log('Attempting to sign in with email:', email)
      
      const { data, error } = await supabase.auth.signInWithPassword({
        email,
        password,
      })

      if (error) {
        console.error('Supabase sign in error:', error)
        throw new ApiError(error.message, 400)
      }

      console.log('Sign in successful:', data.user?.email)
      return data
    } catch (error) {
      console.error('Sign in error:', error)
      throw error
    }
  },

  async signOut() {
    try {
      const { error } = await supabase.auth.signOut()
      if (error) {
        throw new ApiError(error.message, 400)
      }
    } catch (error) {
      console.error('Sign out error:', error)
      throw error
    }
  },

  async getCurrentSession() {
    try {
      const { data: { session }, error } = await supabase.auth.getSession()
      if (error) {
        throw new ApiError(error.message, 400)
      }
      return session
    } catch (error) {
      console.error('Get session error:', error)
      throw error
    }
  },

  // Photo upload
  async uploadPhotos(files: File[]): Promise<Array<{ path: string; url: string; size: number; type: string }>> {
    try {
      const formData = new FormData()
      files.forEach(file => formData.append('photos', file))

      const session = await supabase.auth.getSession()
      const accessToken = session.data.session?.access_token

      const response = await fetch(`${baseUrl}/photos/upload`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${accessToken}`,
        },
        body: formData,
      })

      if (!response.ok) {
        const errorData = await response.json()
        throw new ApiError(errorData.error || 'Upload failed', response.status)
      }

      const data = await response.json()
      return data.files
    } catch (error) {
      console.error('Photo upload error:', error)
      throw error
    }
  },

  // Quotes
  async generateQuote(photos: any[], projectType: string, clientInfo: any): Promise<Quote> {
    try {
      const data = await apiRequest('/quotes/generate', {
        method: 'POST',
        body: JSON.stringify({ photos, projectType, clientInfo }),
      })
      return data.quote
    } catch (error) {
      console.error('Generate quote error:', error)
      throw error
    }
  },

  async getQuotes(): Promise<Quote[]> {
    try {
      const data = await apiRequest('/quotes')
      return data.quotes
    } catch (error) {
      console.error('Get quotes error:', error)
      throw error
    }
  },

  async getQuote(id: string): Promise<Quote> {
    try {
      const data = await apiRequest(`/quotes/${id}`)
      return data.quote
    } catch (error) {
      console.error('Get quote error:', error)
      throw error
    }
  },

  async updateQuoteStatus(id: string, status: string): Promise<Quote> {
    try {
      const data = await apiRequest(`/quotes/${id}`, {
        method: 'PATCH',
        body: JSON.stringify({ status }),
      })
      return data.quote
    } catch (error) {
      console.error('Update quote status error:', error)
      throw error
    }
  },

  // User profile
  async getProfile(): Promise<UserProfile> {
    try {
      const data = await apiRequest('/profile')
      return data.profile
    } catch (error) {
      console.error('Get profile error:', error)
      throw error
    }
  },

  // Health check
  async healthCheck() {
    try {
      const data = await apiRequest('/health')
      return data
    } catch (error) {
      console.error('Health check error:', error)
      throw error
    }
  }
}