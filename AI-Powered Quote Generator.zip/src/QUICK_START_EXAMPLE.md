# 🚀 Quick Start: HVAC Example

Transform the platform into an HVAC quote generator in 10 minutes:

## Step 1: Update Hero (3 min)

**File:** `/components/Hero.tsx`

**Icons (line 2):**
```tsx
import { ArrowRight, Thermometer, Zap, DollarSign } from 'lucide-react';
```

**Headline (lines 16-21):**
```tsx
<h1 className="text-4xl lg:text-6xl tracking-tight">
  Instant HVAC Quotes from Property Photos
</h1>
<p className="text-xl text-muted-foreground max-w-2xl">
  Transform your HVAC business with AI-powered quotes that analyze property size, 
  insulation, and climate factors.
</p>
```

**Features (lines 24-37):**
```tsx
<div className="flex flex-wrap gap-6">
  <div className="flex items-center space-x-2">
    <Thermometer className="h-5 w-5 text-primary" />
    <span>Climate Analysis</span>
  </div>
  <div className="flex items-center space-x-2">
    <Zap className="h-5 w-5 text-primary" />
    <span>Equipment Sizing</span>
  </div>
  <div className="flex items-center space-x-2">
    <DollarSign className="h-5 w-5 text-primary" />
    <span>Cost Optimization</span>
  </div>
</div>
```

## Step 2: Update Company Name (1 min)

**File:** `/components/Header.tsx` line 31:
```tsx
<span className="font-semibold text-xl">HVAC QuotePro</span>
```

## Step 3: Test (1 min)
Save files and refresh browser - you now have an HVAC quote generator!

## Other Industries

Same process works for:
- **Solar:** "Solar Installation Quotes from Satellite Imagery"
- **Roofing:** "Accurate Roofing Estimates from Aerial Analysis"
- **Landscaping:** "Professional Landscape Design with Instant Quotes"

## Next Steps
1. Update `/data/features.tsx` for HVAC-specific features
2. Modify `/data/pricing.tsx` for your pricing
3. Add your logo in Header component
4. Update colors in `/styles/globals.css`