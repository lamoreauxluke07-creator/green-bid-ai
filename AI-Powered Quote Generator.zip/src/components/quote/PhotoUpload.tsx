import { useCallback } from 'react';
import { Button } from '../ui/button';
import { Upload, Camera } from 'lucide-react';

interface PhotoUploadProps {
  uploadedImages: File[];
  onImageUpload: (files: FileList | null) => void;
  onRemoveImage: (index: number) => void;
}

export function PhotoUpload({ uploadedImages, onImageUpload, onRemoveImage }: PhotoUploadProps) {
  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    onImageUpload(e.dataTransfer.files);
  }, [onImageUpload]);

  const handleDragOver = useCallback((e: React.DragEvent) => {
    e.preventDefault();
  }, []);

  return (
    <>
      <div
        className="border-2 border-dashed border-muted-foreground/25 rounded-lg p-12 text-center hover:border-primary/50 transition-colors cursor-pointer"
        onDrop={handleDrop}
        onDragOver={handleDragOver}
        onClick={() => document.getElementById('file-upload')?.click()}
      >
        <Upload className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
        <h3 className="text-lg mb-2">Drop photos here or click to browse</h3>
        <p className="text-muted-foreground mb-4">
          Upload multiple angles for best results. Supports JPG, PNG, WebP
        </p>
        <input
          id="file-upload"
          type="file"
          multiple
          accept="image/*"
          className="hidden"
          onChange={(e) => onImageUpload(e.target.files)}
        />
        <Button variant="outline">
          <Camera className="h-4 w-4 mr-2" />
          Choose Photos
        </Button>
      </div>

      {uploadedImages.length > 0 && (
        <div>
          <h4 className="mb-4">Uploaded Photos ({uploadedImages.length})</h4>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {uploadedImages.map((image, index) => (
              <div key={index} className="relative group">
                <div className="aspect-square rounded-lg overflow-hidden bg-muted">
                  <img
                    src={URL.createObjectURL(image)}
                    alt={`Upload ${index + 1}`}
                    className="w-full h-full object-cover"
                  />
                </div>
                <button
                  onClick={() => onRemoveImage(index)}
                  className="absolute -top-2 -right-2 bg-destructive text-destructive-foreground rounded-full w-6 h-6 flex items-center justify-center text-sm opacity-0 group-hover:opacity-100 transition-opacity"
                >
                  ×
                </button>
              </div>
            ))}
          </div>
        </div>
      )}

      <div className="bg-muted/50 rounded-lg p-4">
        <h4 className="mb-2">Tips for Best Results:</h4>
        <ul className="text-sm text-muted-foreground space-y-1">
          <li>• Take photos from multiple angles</li>
          <li>• Include close-ups of surfaces and materials</li>
          <li>• Ensure good lighting and clear visibility</li>
          <li>• Include reference objects for scale</li>
        </ul>
      </div>
    </>
  );
}