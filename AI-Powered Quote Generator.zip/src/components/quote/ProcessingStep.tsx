import { Card, CardContent } from '../ui/card';
import { Progress } from '../ui/progress';
import { Camera } from 'lucide-react';

interface ProcessingStepProps {
  progress: number;
}

const getProcessingMessage = (progress: number): string => {
  if (progress < 20) return 'Analyzing images...';
  if (progress < 40) return 'Detecting surfaces...';
  if (progress < 60) return 'Calculating measurements...';
  if (progress < 80) return 'Estimating materials...';
  return 'Generating quote...';
};

export function ProcessingStep({ progress }: ProcessingStepProps) {
  return (
    <div className="min-h-screen bg-muted/30 py-20">
      <div className="container mx-auto px-4 max-w-2xl">
        <Card>
          <CardContent className="p-12 text-center">
            <div className="mb-8">
              <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4">
                <Camera className="h-8 w-8 text-primary animate-pulse" />
              </div>
              <h2 className="text-2xl mb-2">Analyzing Your Photos</h2>
              <p className="text-muted-foreground">
                Our AI is processing your images to generate an accurate quote
              </p>
            </div>
            
            <Progress value={progress} className="mb-4" />
            <p className="text-sm text-muted-foreground">
              {getProcessingMessage(progress)}
            </p>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}