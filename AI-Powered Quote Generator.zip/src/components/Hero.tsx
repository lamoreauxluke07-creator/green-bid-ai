import { Button } from './ui/button';
import { ArrowRight, Camera, Zap, Clock } from 'lucide-react';
import { ImageWithFallback } from './figma/ImageWithFallback';

interface HeroProps {
  onGetStarted: () => void;
}

export function Hero({ onGetStarted }: HeroProps) {
  return (
    <section className="py-20 lg:py-32 bg-gradient-to-br from-background to-muted/30">
      <div className="container mx-auto px-4">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <div className="space-y-8">
            <div className="space-y-4">
              <h1 className="text-4xl lg:text-6xl tracking-tight">
                AI-Powered Quotes from Property Photos
              </h1>
              <p className="text-xl text-muted-foreground max-w-2xl">
                Transform your landscaping and construction business with instant, accurate quotes generated from property photos using advanced AI technology.
              </p>
            </div>

            <div className="flex flex-wrap gap-6">
              <div className="flex items-center space-x-2">
                <Camera className="h-5 w-5 text-primary" />
                <span>Photo Analysis</span>
              </div>
              <div className="flex items-center space-x-2">
                <Zap className="h-5 w-5 text-primary" />
                <span>Instant Quotes</span>
              </div>
              <div className="flex items-center space-x-2">
                <Clock className="h-5 w-5 text-primary" />
                <span>Save Hours</span>
              </div>
            </div>

            <div className="flex flex-col sm:flex-row gap-4">
              <Button size="lg" onClick={onGetStarted} className="text-lg px-8">
                Get Your First Quote
                <ArrowRight className="ml-2 h-5 w-5" />
              </Button>
              <Button size="lg" variant="outline" className="text-lg px-8">
                Watch Demo
              </Button>
            </div>

            <div className="flex items-center space-x-8 pt-4">
              <div>
                <div className="text-2xl">10,000+</div>
                <div className="text-sm text-muted-foreground">Quotes Generated</div>
              </div>
              <div>
                <div className="text-2xl">95%</div>
                <div className="text-sm text-muted-foreground">Accuracy Rate</div>
              </div>
              <div>
                <div className="text-2xl">5min</div>
                <div className="text-sm text-muted-foreground">Average Time</div>
              </div>
            </div>
          </div>

          <div className="relative">
            <div className="aspect-square rounded-2xl overflow-hidden bg-muted/50 shadow-2xl">
              <ImageWithFallback
                src="https://images.unsplash.com/photo-1677275968967-7d1506282323?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwcm9mZXNzaW9uYWwlMjBsYW5kc2NhcGluZ3xlbnwxfHx8fDE3NTY0NzQ3OTd8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
                alt="Professional landscaping project"
                className="w-full h-full object-cover"
              />
            </div>
            
            {/* Floating Stats Cards */}
            <div className="absolute -top-4 -right-4 bg-background p-4 rounded-xl shadow-lg border">
              <div className="flex items-center space-x-2">
                <div className="w-3 h-3 bg-green-500 rounded-full"></div>
                <span className="text-sm">Quote Ready</span>
              </div>
              <div className="text-lg">$12,450</div>
            </div>
            
            <div className="absolute -bottom-4 -left-4 bg-background p-4 rounded-xl shadow-lg border">
              <div className="text-sm text-muted-foreground">Processing Time</div>
              <div className="text-lg">2.3 seconds</div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}